# SHACK-SERVER Architecture Book

**Part I – Core Architecture**

> This document is the official architecture book for SHACK-SERVER.

## Status

This repository contains the approved structure for Part I.

The chapter contents discussed during the design sessions will be inserted into this document without further restructuring.

## Chapters

1. Project Identity
2. The Problem
3. Design Goals
4. Core Principles
5. Ubiquitous Language
6. Domain Model
7. System Architecture
8. Data Sources
9. Collectors
10. Message Classifier
11. Spot Parser
12. Fusion Engine
13. Spot Store
14. Rule Engine
15. Output Interfaces
